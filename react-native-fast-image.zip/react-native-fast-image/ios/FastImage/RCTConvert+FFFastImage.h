#import <React/RCTConvert.h>

@class FFFastImageSource;

@interface RCTConvert (FFFastImage)

+ (FFFastImageSource *)FFFastImageSource:(id)json;

@end
