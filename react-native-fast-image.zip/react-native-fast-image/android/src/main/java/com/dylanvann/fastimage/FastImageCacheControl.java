package com.dylanvann.fastimage;

public enum FastImageCacheControl {
    IMMUTABLE,
    WEB,
    CACHE_ONLY
}

